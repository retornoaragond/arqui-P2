---
id: composer_4
name: Hans Zimmer
birth_date: 12 de septiembre de 1957
nationality: Alemán
music_genres:
  - Música de Cine
  - Música Orquestal
  - Música Electrónica
image: composers/composer_4.jpg
---

Hans Zimmer es un composer alemán nacido el 12 de septiembre de 1957. Es uno de los composeres más influyentes en la música de cine y es conocido por su enfoque innovador. Ha compuesto música para películas como "Gladiator", "Interstellar" e "Inception", abarcando géneros que van desde lo orquestal hasta lo electrónico.
