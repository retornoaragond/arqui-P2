---
id: composer_6
name: James Horner
birth_date: 14 de agosto de 1953
nationality: Estadounidense
music_genres: 
  - Música de Cine 
  - Música Clásica
image: composers/composer_6.jpg
---

James Horner fue un composer estadounidense nacido el 14 de agosto de 1953 y fallecido en 2015. Durante su carrera, compuso música para una amplia variedad de películas, incluyendo "Titanic". Su legado musical incluye melodías emotivas y piezas conmovedoras que han dejado una huella en la música de cine.