---
id: composer_1
name: Klaus Badelt
birth_date: 12 de junio de 1967
nationality: Alemán
music_genres: 
  - Música de Cine 
  - Música Orquestal
image: composers/composer_1.jpg
---

Klaus Badelt es un composer alemán nacido el 12 de junio de 1967. Es conocido por su trabajo en la música de cine y música orquestal. Ha colaborado en la composición de bandas sonoras para numerosas películas, incluyendo "Piratas del Caribe: La maldición de la Perla Negra". Su música es conocida por su estilo aventurero y épico.
