---
id: composer_3
name: Howard Shore
birth_date: 18 de octubre de 1946
nationality: Canadiense
music_genres: 
  - Música de Cine 
  - Música Clásica
image: composers/composer_3.jpg
---

Howard Shore es un composer canadiense nacido el 18 de octubre de 1946. Es conocido por su versatilidad en la composición de música de cine y música clásica. Ganó reconocimiento por su trabajo en la trilogía de "El Señor de los Anillos" y ha colaborado en una amplia variedad de proyectos musicales.