---
id: composer_5
name: Justin Hurwitz
birth_date: 22 de enero de 1985
nationality: Estadounidense
music_genres: 
  - Música de Cine 
  - Música Orquestal
image: composers/composer_5.jpg
---

Justin Hurwitz es un composer estadounidense nacido el 22 de enero de 1985. Ganó reconocimiento por su trabajo en la música de la película "La La Land", por la cual recibió premios y reconocimientos. Su estilo musical es conocido por su elegancia y su habilidad para combinar elementos clásicos con contemporáneos.
