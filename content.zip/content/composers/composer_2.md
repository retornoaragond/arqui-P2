---
id: composer_2
name: John Williams
birth_date: 8 de febrero de 1932
nationality: Estadounidense
music_genres: 
  - Música de Cine 
  - Música Clásica
image: composers/composer_2.jpg
---

John Williams es un destacado composer estadounidense nacido el 8 de febrero de 1932. Es ampliamente reconocido por su contribución a la música de cine y música clásica. Ha compuesto algunas de las bandas sonoras más icónicas de la historia del cine, como las de "Star Wars", "Jurassic Park" y "E.T. el Extraterrestre".
