---
id: album_5
title: Gladiator (Music from the Motion Picture)
composerId: composer_4
movieId: movie_5
release_year: 2000
genres: Música de Cine, Música Orquestal, Música Épica
record_label: Decca Records
tracks: 17
image: albums/album_5.jpg
---

Hans Zimmer crea una poderosa y épica banda sonora para "Gladiator". Esta música te sumerge en la Roma antigua mientras acompañas a Maximus en su búsqueda de venganza en el coliseo.
