---
id: album_10
title: Titanic - Music from the Motion Picture
composerId: composer_6
movieId: movie_10
release_year: 1997
genres: Música de Cine, Romance, Drama
record_label: Sony Classical
tracks: 15
image: albums/album_10.jpg
---

Esta banda sonora inolvidable de James Horner te lleva a bordo del legendario Titanic. La música refleja la grandeza y el romance de la trágica historia de Jack y Rose.
