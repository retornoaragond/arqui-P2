---
id: album_4
title: Jurassic Park (Original Motion Picture Soundtrack)
composerId: composer_2
movieId: movie_4
release_year: 1993
genres: Música de Cine, Música Clásica
record_label: MCA Records
tracks: 14
image: albums/album_4.jpg
---

La partitura de John Williams para "Jurassic Park" te transporta a un mundo donde los dinosaurios vuelven a la vida. La música captura la maravilla y el peligro de un parque lleno de criaturas prehistóricas.
