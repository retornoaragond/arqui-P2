---
id: album_8
title: Interstellar (Original Motion Picture Soundtrack)
composerId: composer_4
movieId: movie_8
release_year: 2014
genres: Música de Cine, Ciencia Ficción, Drama
record_label: WaterTower Music
tracks: 16
image: albums/album_8.jpg
---

Hans Zimmer crea una experiencia sonora única en "Interstellar". La música te sumerge en el espacio profundo y te lleva a través de agujeros de gusano y planetas lejanos en esta odisea científica.
