---
id: album_2
title: Star Wars- Episode IV - A New Hope (Original Motion Picture Soundtrack)
composerId: composer_2
movieId: movie_2
release_year: 1977
genres: Música de Cine, Música Clásica
record_label: 20th Century Records
tracks: 16
image: albums/album_2.jpg
---

La icónica música de John Williams te llevará a una galaxia muy, muy lejana. Este álbum captura la magia de "Star Wars: Episodio IV - Una nueva esperanza" y te sumerge en una historia épica de héroes y villanos.
