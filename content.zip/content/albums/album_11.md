---
id: album_11
title: E.T. the Extra-Terrestrial (Original Motion Picture Soundtrack)
composerId: composer_2
movieId: movie_11
release_year: 1982
genres: Música de Cine, Ciencia Ficción, Aventura, Familia
record_label: MCA Records
tracks: 15
image: albums/album_11.jpg
---

La música de John Williams para "E.T. el Extraterrestre" te sumerge en la magia de la amistad entre un niño y un adorable extraterrestre. Esta banda sonora emocional evoca la maravilla de la infancia.
