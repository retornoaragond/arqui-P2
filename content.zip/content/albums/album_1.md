---
id: album_1
title: Banda sonora original de Piratas del Caribe
composerId: composer_1
movieId: movie_1
release_year: 2003
genres: Música de Cine, Música Orquestal
record_label: Walt Disney Records
tracks: 12
image: albums/album_1.jpg
---

Sumérgete en el emocionante mundo de los piratas con esta banda sonora llena de aventuras y misterio. La música de Klaus Badelt te transportará a los mares turbulentos y las épicas batallas de "Piratas del Caribe: La maldición de la Perla Negra".
