---
id: album_3
title: The Lord of the Rings - The Fellowship of the Ring - Original Motion Picture Soundtrack
composerId: composer_3
movieId: movie_3
release_year: 2001
genres: Música de Cine, Música Clásica
record_label: Reprise Records
tracks: 18
image: albums/album_3.jpg
---

Viaja a la Tierra Media con la majestuosa música de Howard Shore. Esta banda sonora acompaña la búsqueda del Anillo Único en "El Señor de los Anillos: La Comunidad del Anillo" y te envuelve en un mundo de fantasía y aventura.
