---
id: album_7
title: La La Land (Original Motion Picture Soundtrack)
composerId: composer_5
movieId: movie_7
release_year: 2016
genres: Música de Cine, Musical, Romance, Drama
record_label: Interscope Records
tracks: 15
image: albums/album_7.jpg
---

Embárcate en un viaje musical por Los Ángeles con la cautivadora banda sonora de "La La Land". Esta música llena de romance y jazz te sumerge en la historia de amor de Mia y Sebastian.
