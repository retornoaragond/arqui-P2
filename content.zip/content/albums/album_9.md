---
id: album_9
title: The Lion King (Original Motion Picture Soundtrack)
composerId: composer_4
movieId: movie_9
release_year: 1994
genres: Música de Cine, Música Orquestal
record_label: Walt Disney Records
tracks: 12
image: albums/album_9.jpg
---

La música de Elton John y Hans Zimmer es la banda sonora de la vida en la sabana africana. "El Rey León" cobra vida con canciones memorables y música orquestal que celebra el ciclo de la vida.
