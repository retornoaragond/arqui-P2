---
id: album_12
title: Inception (Music from the Motion Picture)
composerId: composer_4
movieId: movie_12
release_year: 2010
genres: Música de Cine, Ciencia Ficción, Acción, Misterio
record_label: Reprise Records
tracks: 12
image: albums/album_12.jpg
---

La partitura de Hans Zimmer para "Origen" es un viaje sonoro a través de sueños y realidades entrelazadas. La música te sumerge en un mundo de intriga y misterio mientras exploras los límites de la mente.
