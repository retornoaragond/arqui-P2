---
id: album_6
title: Harry Potter and the Sorcerer's Stone (Original Motion Picture Soundtrack)
composerId: composer_2
movieId: movie_6
release_year: 2001
genres: Música de Cine, Música Orquestal
record_label: Atlantic Records
tracks: 19
image: albums/album_6.jpg
---

La música de John Williams te lleva al mundo mágico de Hogwarts en "Harry Potter y la piedra filosofal". La banda sonora evoca la magia y la emoción de las aventuras de Harry, Ron y Hermione.
