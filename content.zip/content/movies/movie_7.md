---
id: movie_7
title: La La Land
director: Damien Chazelle
release_year: 2016
genres: 
  - Musical
  - Romance
  - Drama
image: movies/movie_7.jpg
---

Mia, una aspirante a actriz, y Sebastian, un pianista de jazz, se enamoran en Los Ángeles mientras persiguen sus sueños. La película es un homenaje a la música y el cine clásico.
