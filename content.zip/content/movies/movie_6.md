---
id: movie_6
title: Harry Potter y la piedra filosofal
director: Chris Columbus
release_year: 2001
genres: 
  - Aventura
  - Fantasía
image: movies/movie_6.jpg
---

El joven mago Harry Potter descubre que es un mago y se embarca en su primer año en Hogwarts, donde se enfrenta a misterios y desafíos mientras busca la Piedra Filosofal, que otorga la inmortalidad.
