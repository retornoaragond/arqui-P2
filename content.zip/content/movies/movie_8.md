---
id: movie_8
title: Interstellar
director: Christopher Nolan
release_year: 2014
genres: 
  - Ciencia Ficción
  - Drama
image: movies/movie_8.jpg
---

En un futuro distópico, un grupo de astronautas emprende un viaje interestelar en busca de un nuevo hogar para la humanidad, mientras luchan contra el tiempo y los desafíos cósmicos.
