---
id: movie_3
title: El Señor de los Anillos- La Comunidad del Anillo
director: Peter Jackson
release_year: 2001
genres: 
  - Aventura
  - Fantasía
image: movies/movie_3.jpg
---
Frodo Bolsón emprende un viaje épico para destruir un poderoso anillo que amenaza con caer en manos del Señor Oscuro Sauron. Se une a una compañía de personajes dispuestos a enfrentar peligros en un mundo de fantasía.
