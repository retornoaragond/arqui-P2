---
id: movie_1
title: Piratas del Caribe - La maldición de la Perla Negra
director: Gore Verbinski
release_year: 2003
genres: 
  - Aventura
  - Fantasía
image: movies/movie_1.jpg
---

El capitán Jack Sparrow se embarca en una aventura para recuperar su barco, La Perla Negra, y enfrentarse a una tripulación de piratas malditos que buscan una misteriosa maldición que los condena a la no-muerte.
