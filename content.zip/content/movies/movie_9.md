---
id: movie_9
title: El Rey León
director: Roger Allers, Rob Minkoff
release_year: 1994
genres: 
 - Animación
 - Aventura 
 - Drama
image: movies/movie_9.jpg
---

Simba, un joven león, debe enfrentar su destino como rey de la sabana africana después de ser desterrado por su malvado tío Scar. La película es un conmovedor relato sobre el ciclo de la vida.
