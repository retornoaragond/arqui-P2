---
id: movie_5
title: Gladiator
director: Ridley Scott
release_year: 2000
genres: 
  - Acción
  - Drama
  - Épica
image: movies/movie_5.jpg
---

Maximus, un valiente general romano, es traicionado y llevado al coliseo como gladiador. Busca venganza contra el corrupto emperador Cómodo mientras lucha por su libertad y el honor de Roma.
