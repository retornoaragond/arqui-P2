---
id: movie_11
title: E.T. el Extraterrestre
director: Steven Spielberg
release_year: 1982
genres: 
  - Ciencia Ficción
  - Aventura
  - Familia
image: movies/movie_11.jpg
---

Un niño llamado Elliott forma un vínculo especial con un amigable extraterrestre que se encuentra en su casa. Juntos, intentan proteger a E.T. de las autoridades y ayudarlo a regresar a su hogar.
