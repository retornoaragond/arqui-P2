---
id: movie_2
title: Star Wars - Episodio IV - Una nueva esperanza
director: George Lucas
release_year: 1977
genres: 
  - Ciencia Ficción 
  - Fantasía
image: movies/movie_2.jpg
---

En un lejano sistema estelar, un joven llamado Luke Skywalker se une a un grupo de rebeldes para enfrentar al malvado Imperio Galáctico, liderado por Darth Vader, y rescatar a la Princesa Leia.
