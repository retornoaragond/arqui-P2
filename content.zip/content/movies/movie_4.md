---
id: movie_4
title: Jurassic Park
director: Steven Spielberg
release_year: 1993
genres: 
  - Ciencia Ficción
  - Aventura
image: movies/movie_4.jpg
---

Un grupo de científicos y aventureros visita una isla remota donde un excéntrico millonario ha creado un parque temático lleno de dinosaurios vivos. Pronto, el parque se convierte en una pesadilla cuando los dinosaurios escapan.
