---
id: movie_12
title: Inception
director: Christopher Nolan
release_year: 2010
genres: 
  - Ciencia Ficción
  - Acción
  - Misterio
image: movies/movie_12.jpg
---

Dom Cobb es un ladrón de sueños que se introduce en las mentes de las personas para robar secretos. Recibe la tarea de implantar una idea en la mente de alguien, desencadenando una serie de realidades entrelazadas.
