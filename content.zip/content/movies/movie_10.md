---
id: movie_10
title: Titanic
director: James Cameron
release_year: 1997
genres: 
  - Drama
  - Romance
image: movies/movie_10.jpg
---

La película narra la historia de amor entre Jack y Rose, dos pasajeros del Titanic, el famoso barco que se hundió en su viaje inaugural. Su romance se desarrolla en medio de la tragedia.
